
/**
 * Write a description of class Punto1_2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PuntoTablas{
    
    public static void tablasMultiplicar(int n){
        for (int i = 0; i < n; i++){
            for (int j = 0; j < n; j++){
                //System.out.println(i+"*"+j+"="+i*j);
            }
        }   
    }
    
    public static long tomarTiempo(int n){
        long startTime = System.currentTimeMillis();
        tablasMultiplicar(n);
        long estimatedTime = System.currentTimeMillis() - startTime;
        return estimatedTime;
    }
    
    public static void main(String[] args){
        for(int i = 100000; i <= 100000000; i = i*10){
        System.out.println(i+" "+tomarTiempo(i));
       }
    }
    
}
