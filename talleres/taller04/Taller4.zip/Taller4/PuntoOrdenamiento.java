import java.util.Random;
public class PuntoOrdenamiento{
    public static void ordenamiento(int[] a){
        for(int i=0; i<a.length; i++){
            int j=i;
            while(j > 0 && a[j-1] > a[j]){
                int temp = a[j];
                a[j] = a[j-1];
                a[j-1] = temp;
                j = j - 1;
            }
        }
    }
    
    public static long tomarTiempo(int n){
        int[] a = generarArregloDeTamanoN(n);
        long startTime = System.currentTimeMillis();
        ordenamiento(a);
        long estimatedTime = System.currentTimeMillis() - startTime;
        return estimatedTime;
    }
    
    public static int[] generarArregloDeTamanoN(int n){
        int max = 5000;
        int[] array = new int[n];
        Random generator = new Random();
        for (int i =0; i<n; i++){
            array[i] = generator.nextInt(max);
        }
        return array;
    }
    
    public static void main(String[] args){
        for(int i=100000; i<=100000000; i*=10){
            System.out.println(i + ", " + tomarTiempo(i));
        }
    }
}
